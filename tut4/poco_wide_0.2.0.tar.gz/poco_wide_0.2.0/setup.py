import glob

__version__ = '0.2.0'

setup_args = {
    'name': 'poco_wide',
    'author': 'Jason Manley',
    'author_email': 'jason_manley at hotmail.com',
    'license': 'GPL',
    'package_dir': {'poco_wide':'src'},
    'packages': ['poco_wide'],
    'scripts': glob.glob('scripts/*.*'),
    'package_data': {'poco_wide': ['LICENSE.txt']},
    'version': __version__,
}

if __name__ == '__main__':
    from distutils.core import setup
    apply(setup, (), setup_args)
